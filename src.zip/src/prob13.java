/**
 * Created by Hamza on 3/7/2015.
 */
public class prob13 {
    public static void main(String[] args){

    }
}
