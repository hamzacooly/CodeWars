/**
 * Created by Hamza on 3/7/2015.
 */
public class prob12 {
    public static void main(String[] args){

    }
}
