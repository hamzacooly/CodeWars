/**
 * Created by Hamza on 3/7/2015.
 */
public class prob00 {
    public static void main(String[] args){
        System.out.println("Welcome, Barcelona and Newcastle!");
    }
}
